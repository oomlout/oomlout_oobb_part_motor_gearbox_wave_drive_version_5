# Assemble the opposed roller wave drive

This sequence applies to the default 7 × 12 mm nylon-spacer build. The gearbox has 26 printed pieces, 40 purchased rollers, two 6810 and four 6704 bearings. Consult the generated hardware YAML for exact quantities.

## Print and fit

Print the five numbered 220 × 220 mm bed STLs. All production pieces have their bed face at Z=0. The upper cage is printed with its floor down and inverted for assembly. Both wave wheels and their caps are identical. The two cam parts and the two fixed profile rings are deliberately different.

Print `fit_coupons.stl` first. The first row checks the 6810 seat, 6704 seat, 6810 journal and 6704 journal at X=0,65,110,150 mm. The second row at Y=55 checks the D shaft, nylon roller slot, a demonstration roller and an M3 nut pocket at X=0,40,70,100 mm. The demonstration roller is a fit sample; use purchased nylon spacers in the gearbox.

Default rollers are 7 mm OD × 12 mm long, with an assumed 3.2 mm bore. There are no pins through those bores. Remove burrs from spacer ends and verify that each roller slides freely in its cage window. OOBB nut/socket cuts have overhang compensation enabled; remove remaining bridge debris before inserting hardware. Bearing seats and shaft fit must be checked with the actual purchased parts.

## Default hardware

| Quantity | Item | Use |
| --- | --- | --- |
| 40 | Nylon spacer, 7 OD × 12 mm, assumed 3.2 ID | Two banks of twenty free rollers |
| 2 | 6810 bearing, 50 × 65 × 7 mm | Output support |
| 4 | 6704 bearing, 20 × 27 × 4 mm | Two input supports and two wave wheels |
| 1 | 5 mm D shaft, 85 mm long | Shared input; 0.5 mm deep flat |
| 32 | M3 × 12 socket cap | 16 end-housing and 16 output-hub joints |
| 16 | M3 × 14 socket cap | Profile rings to stationary centre ring |
| 8 | M3 × 6 socket cap | Wave bearing caps |
| 10 | M2 × 16 socket cap | Cage halves to central output plate |
| 2 | M3 × 8 grub screw | Input collars |
| 58 | M3 hex nut | Cases, fixed joints, hubs, wave caps and collars |
| 10 | M2 hex nut | Common cage centre joint |

Socket-cap lengths are measured **under the head**. The default output-retainer heads project approximately 1 mm outside their retainer faces; the housing opening clears them. Do not substitute countersunk heads. Changing nylon length changes the ring-join and cage screws; regenerate and use the new BOM. Every supported option stays below the 35 mm limit.

## Assembly order

1. Load eight M3 nuts into each cage floor and four into each wave wheel. The wave nuts drop into the deeper hex wells exposed before the bearing cap is installed. Load the two collar nuts through their face slots.
2. Fit a 6704 bearing into each wave wheel. Install its cap with four M3 × 6 socket caps. Each cap must sit flush in its recess while the bearing remains free.
3. Fit the input pieces to the D shaft: lower collar, lower journal, outer spacer, lower eccentric cam, lower middle spacer, upper middle spacer, upper eccentric cam, outer spacer, upper journal and upper collar. The middle spacer shoulders face their respective wave bearings. The upper and lower cam offsets are opposite; keep their D flats aligned with the shaft. The two wave assemblies slide over their corresponding cam journals as this stack is built.
4. Load five M2 nuts into each face of the central output plate. Join the lower and upper cages to this plate using their different five-hole patterns and M2 × 16 socket caps. This makes a single rigid output cage. Keep the wave wheels and input stack within it; the centre plate surrounds the middle input spacers. Slide the stationary centre ring over a cage and around this plate **before loading the rollers**, engraved `UP` face towards the upper bank.
5. Put twenty nylon rollers into each bank's radial windows. For the 12 mm default, either axial or radial loading is possible before closing the respective parts. For 6 mm rollers, use radial loading through the shorter windows. Do this before sliding the fixed profile rings into place.
6. Load eight M3 nuts into each face of the stationary centre ring. Fit the lower and upper fixed profile rings using their keyed, asymmetric joint-hole patterns. The upper internal profile is phase shifted; do not interchange rings or force a ring over the rollers. Lightly turn the input and cage to seat them, then fit the sixteen M3 × 14 joint screws from the outer ends. These screw pockets must remain accessible until the end housings are installed.
7. Fit the two 6810 bearings in the end housings and the two remaining 6704 bearings into the output hubs. Install the hubs onto the cage floors and the outer output retainers, using eight M3 × 12 socket caps per end. The smaller bearings support the input journals inside the rotating output hubs.
8. Insert the sixteen housing nuts through the radial slots in the profile rings. Attach the two rounded OOBB end housings using eight M3 × 12 socket caps per end. Tighten evenly, keeping the input and output free to rotate.
9. Set the collar positions without axially preloading the bearings. Tighten the two M3 × 8 grub screws against the D flat. Check each bank for trapped rollers and confirm no nut projects into a moving surface.
10. Turn the input slowly by hand. Twenty input revolutions should give one output revolution in the opposite direction. Investigate any repeating tight spot before motor operation.

## Motor and speed

The drawing includes the previous 40 mm NEMA 17 motor as a full fit reference, with a separate 24 mm motor shaft. The gearbox's 85 mm shaft is **not** the motor shaft. A motor bracket and coupling/revised input connection are not part of this print set: only 2 mm of input shaft is exposed below the lower collar. The motor view deliberately shows this unresolved interface.

The opposed banks reduce the net eccentric force but can leave an axial rocking couple. Nylon tolerances, wear, heat and dynamic balance have not been physically tested. Begin with the hand test and a restrained low-speed prototype test after designing the real motor connection.
