"""One command for the complete, SCAD-only project pipeline."""
import argparse
import working_oomp_populate
import working_oomp
import working_scad


def main(**kwargs):
    working_oomp_populate.main()
    working_oomp.main()
    working_scad.main(**kwargs)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--render", action="store_true", help="Render every printable STL")
    parser.add_argument("--images", action="store_true", help="Render assembly, cutaway and print previews")
    main(**vars(parser.parse_args()))

