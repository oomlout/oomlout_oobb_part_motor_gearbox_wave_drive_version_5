"""Render-backed axial-stack checks for every requested nylon spacer length."""
import json
from pathlib import Path
import sys

import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import working_scad


def main():
    folder=next((ROOT/"parts").iterdir())
    target=ROOT/"presentation/cache/stock_lengths"
    target.mkdir(parents=True,exist_ok=True)
    report=[]
    for length in [6,12,15,18,20,25,30]:
        c=working_scad.resolve(roller_length=length)
        result={
            "roller_length_mm":length,
            "assembly_height_mm":c["assembly_height"],
            "wave_height_mm":c["wave_height"],
            "roller_end_clearance_mm":c["roller_end_clearance"],
            "ring_join_screw_mm":c["ring_join_screw_length"],
            "cage_screw_mm":c["cage_screw_length"],
            "maximum_screw_mm":max(r.get("length_mm",0) for r in working_scad.bom(**c)),
            "angles":[],
        }
        for angle in [0,45]:
            path=target/f"collision_L{length}_a{angle}.stl"
            working_scad.render_scad(folder/"collision_check.scad",path,options=["-D",f"roller_length={length}","-D",f"check_angle={angle}"])
            mesh=trimesh.load(path,force="mesh")
            solids=[p for p in mesh.split(only_watertight=False) if min(p.extents)>1e-7]
            assert len(solids)==1 and np.allclose(solids[0].bounds,[[70,0,0],[71,1,1]],atol=1e-5),(length,angle)
            result["angles"].append({"input_angle":angle,"interference_mm3":0})
        report.append(result)
        print("PASS spacer length",length,flush=True)
    # The short spacer has closed axial stops in a deeper wave-bearing bay.
    for name in ["output_cage_lower","output_cage_upper","wave_generator","wave_bearing_cap"]:
        path=target/(name+"_6mm.stl")
        working_scad.render_scad(folder/(name+".scad"),path,options=["-D","roller_length=6"])
        mesh=trimesh.load(path,force="mesh")
        assert mesh.is_watertight and mesh.volume>0 and len(mesh.split())==1,name
    (ROOT/"presentation/stock_lengths_validation.json").write_text(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
