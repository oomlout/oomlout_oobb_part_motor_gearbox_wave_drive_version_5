"""Check the rendered nominal socket caps and nuts against the actual native SCAD."""
import json
from pathlib import Path
import sys

import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import working_scad


def main():
    folder=next((ROOT/"parts").iterdir())
    records=json.loads((ROOT/"presentation/cache/instances.json").read_text())
    fasteners=[r for r in records if r["kind"]=="fastener"]
    prefix="\n".join(f"include <{(folder/name).as_posix()}>" for name in ["parameters.scad","oobb_hardware.scad","geometry.scad"])
    calls=[]
    for r in fasteners:
        mesh=ROOT/"presentation/hardware"/(r["part"]+".stl")
        calls.append(f'multmatrix({json.dumps(r["matrix"])}) import("{mesh.as_posix()}");')
    body=prefix+"\ntranslate([80,0,0]) cube([1,1,1]);\nintersection() { assembly(0); union() {\n"+"\n".join(calls)+"\n} }\n"
    path=ROOT/"presentation/cache/fastener_check.scad"
    path.write_text(body)
    working_scad.render_scad(path,path.with_suffix(".stl"))
    mesh=trimesh.load(path.with_suffix(".stl"),force="mesh")
    solids=[p for p in mesh.split(only_watertight=False) if min(p.extents)>1e-7]
    passed=len(solids)==1 and np.allclose(solids[0].bounds,[[80,0,0],[81,1,1]],atol=1e-5)
    report={
        "status":"passed" if passed else "failed",
        "fastener_instances":len(fasteners),
        "volumetric_components":[{"bounds_mm":p.bounds.tolist(),"volume_mm3":float(p.volume)} for p in solids],
        "scope":"Nominal screw and nut envelopes against every native gearbox body at input angle zero; excludes internal threads.",
    }
    (ROOT/"presentation/fastener_validation.json").write_text(json.dumps(report,indent=2))
    assert passed, report
    print(f"PASS: {len(fasteners)} socket-cap/grub/nut envelopes clear the native gearbox.")


if __name__=="__main__":
    main()
