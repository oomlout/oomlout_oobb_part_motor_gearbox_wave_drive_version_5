# OOBB opposed roller wave drive — 20:1 — 6810 / 6704

Two rigid wave wheels run on **180-degree opposed eccentrics**. Each drives its own bank of 20 loose nylon spacer rollers inside a 21-cavity fixed profile. Both banks drive one common, three-piece output cage at **-1/20 input speed**. There is no flexible spline and no fixed pin ring.

![Exploded gearbox and motor](presentation/images/exploded_motor.png)

The default is **40 nylon spacers, 7 mm OD × 12 mm long**, with an editable 3.2 mm bore assumption. Supported stock lengths are **6, 12, 15, 18, 20, 25 and 30 mm**. Nylon rollers are purchased hardware and are excluded from the print beds. There are **19 printable designs / 26 printed instances**, spread over five 220 × 220 mm beds.

## Open and build

- `working.scad`: assembled gearbox and full motor fit reference.
- `parts/oobb_part_motor_gearbox_wave_drive_version_5_20_to_1_reduction/motor_fit.scad`: full 40 mm NEMA 17 alongside the assembled gearbox.
- `parts/oobb_part_motor_gearbox_wave_drive_version_5_20_to_1_reduction/exploded_motor.scad`: native SCAD exploded reference.
- [Blender exploded view](presentation/images/exploded_motor.png), [motor fit](presentation/images/motor_fit.png), [side elevation](presentation/images/motor_side.png), [open lower bank](presentation/images/open_mechanism.png).
- [Editable Blender scenes](presentation/scenes/wave_drive.blend): seven named scenes with separately selectable bodies.
- [Print pack](release/wave_drive_20_to_1_print_pack.zip) and [assembly instructions](ASSEMBLY.md).

```powershell
python working.py --render --images
python -m pytest -q
python tools/validate_meshes.py
python tools/validate_stock_lengths.py
python working_blender.py
python tools/validate_fasteners.py
python tools/package_release.py
```

The small, editable pipeline is `working_oomp_populate.define(**kwargs)` → `working_oomp.py` → `working_scad.py`. Mechanical defaults live in the multiline dictionary in [working_oomp_populate.py](working_oomp_populate.py). The axial stack and piece/hardware recipes live in [dual_recipe.py](wave_components/dual_recipe.py); native geometry lives in [wave_drive.scad](wave_components/wave_drive.scad). Functions copy incoming kwargs and forward settings explicitly. `roller_length` selects the stock size; dependent spacers, casing lengths, shaft length and screw choices follow it.

Opening generated SCAD requires only OpenSCAD. Python regeneration requires local OOBB v5 / OOMP v5 and `requirements.txt`. Here these are installed from `C:/gh/oomlout_oobb_version_5` and `C:/gh/oomlout_oomp_version_5`. OpenSCAD with its Manifold backend and Blender must be on PATH for the respective exports.

## Fasteners, bearings and plates

All assembly bolts use **socket caps**, with a hard **35 mm maximum under-head length**. The default uses M3 × 6, M3 × 12, M3 × 14 and M2 × 16 socket caps, plus M3 × 8 collar grub screws. The default longest socket cap is 16 mm. Each end housing attaches to its profile ring; separate bolts join those rings to the stationary centre ring. The output cage halves similarly attach to a central output plate. This avoids a single long through-bolt.

All nut pockets, socket heads and named clearance holes use OOBB with `overhang=True`. A missing M2 socket-cap dimension entry is filled in memory in this project; the shared OOBB checkout is not edited. Its nominal head dimensions follow the [Accu DIN 912 / ISO 4762 data sheet](https://www.accu.co.uk/api/product-datasheet?id=2775).

| Item | Default |
| --- | --- |
| Output bearings | 2 × 6810, 50 × 65 × 7 mm |
| Input/wave bearings | 4 × 6704, 20 × 27 × 4 mm |
| Nylon rollers | 2 banks × 20; 7 mm OD × 12 mm; bore assumed 3.2 mm |
| Eccentricity / wave diameter | 0.75 mm / 80 mm |
| Fixed-ring outside diameter | 115 mm |
| OOBB mounting plates | 119 × 119 mm; 1.5 mm corner radii |
| Housing axial height | 57.6 mm |
| Input | 5 mm D shaft, 85 mm long, 0.5 mm flat depth |
| Output cage radial wall | 4 mm |
| Ring running / roller-slot clearance | 0.15 mm normal / 0.30 mm total tangential |
| Roller end clearance | 0.30 mm at each end |

The mounting plate outline uses the same four-cylinder hull as OOBB's rounded rectangle. `housing_flange_corner_radius` controls the 1.5 mm corner radius directly in Python and SCAD.

| Nylon spacer length | Housing height | Longest screw |
| --- | --- | --- |
| 6 mm | 54 mm | 14 mm |
| 12 mm | 57.6 mm | 16 mm |
| 15 mm | 63.6 mm | 18 mm |
| 18 mm | 69.6 mm | 20 mm |
| 20 mm | 73.6 mm | 20 mm |
| 25 mm | 83.6 mm | 25 mm |
| 30 mm | 93.6 mm | 30 mm |

The 6 mm roller option still needs a 10.2 mm wave wheel to contain its 6704 bearing and socket-cap retainer. Its cage windows have additional axial lips, maintaining 0.3 mm end clearance; load those rollers radially before installing the fixed profile rings. The upper window lips bridge approximately 7.3 mm when printed. The bore size does not locate the roller on a pin: the rollers remain free in radial cage windows.

## Phase and vibration

One shared set of straight rollers cannot follow both opposed wheels: the required radial positions differ by up to **1.5 mm**. The two banks therefore have independent rollers and a common output cage. The upper fixed profile is clocked **180/21 = 8.5714286 degrees** relative to the lower profile, while both banks share the same cage angle. One offset joint screw keys each stationary profile ring to the centre ring; its engraved `UP` label identifies the upper face.

The opposed wheel centres cancel the first-order eccentric displacement for equal masses. They occupy different axial planes, so a rocking couple can remain. This is a geometric prototype, not a balanced rotor or an established high-speed/torque rating. Physical fit, nylon deformation and friction, heat, wear, backlash and vibration require bench testing.

## Full motor reference

The requested previous motor is shown with a 42.3 × 42.3 × 40 mm body, 24 mm shaft, 22 × 2 mm pilot and 31 mm mounting pitch. End-cap, chamfer and connector details are illustrative. Edit [motor_reference.py](presentation/motor_reference.py) to change the reference dimensions.

This is an **aligned fit study**, not a completed motor conversion. The motor face is 37 mm below the gearbox mounting face, with a 1 mm gap between the separate shaft ends. The gearbox shaft projects only 2 mm below its lower collar. A mounting bracket and a coupling or revised input connection are still required. No fictitious coupling or continuous shaft is drawn. [motor_fit.json](presentation/motor_fit.json) records the dimensions and the zero-interference envelope check.

## Rendering and checks

The cycloidal project's polished images used Blender Cycles; SolidCraft supplied its old meshes. This project uses **OpenSCAD STL → Blender Cycles → Pillow sheets**, preserving the turquoise, black and sunflower materials, orthographic cameras, four softboxes and cream background. Nylon spacers use natural ivory. Edit [style.json](presentation/style.json) for lighting, materials and cameras. There is no SolidCraft runtime, STEP conversion, or import from the cycloidal project.

The tests sweep both banks through 361 input poses, check the ratio and phase, compare the independent cam-circle geometry to each ring profile, verify all seven stock-length stacks and screw engagement, and check complete print inventories. Render-backed checks cover every printed solid, eight default collision poses, two poses for each stock length, the short-roller cage lips, all 136 nominal fastener envelopes, and the motor envelope. Six separately exported native assemblies verify Blender part registration by bounds and volume. Results live in `parts/.../mesh_validation.json`, `presentation/validation.json`, `presentation/fastener_validation.json` and `presentation/stock_lengths_validation.json`.

Mishin Machine's [reference](https://urals.co/mshn/wgwr), full Python gist, 852-line FeatureScript, three signed-in Onshape STEP exports, SVG icon and transcribed variables are archived under [references/mishin](references/mishin). The cycloidal folder stays read-only. The previous single-bank build is preserved in `release/single_bank_6x8_reference.zip`.
