# Project instructions

- The user's preferred name is Martin McDoozle.
- Keep `C:/gh/oomlout_oobb_part_motor_gearbox_cycloidal_version_5` read-only.
- This project is an intermediate-roller wave drive, not a harmonic drive.
- Author settings in `working_oomp_populate.py`, catalogue loading in `working_oomp.py`, and drawing/export in `working_scad.py`.
- Use verbose dictionaries, `copy.deepcopy`, `kwargs.setdefault`, and `**kwargs` forwarding. Keep mechanical defaults easy to edit.
- Use OpenSCAD for geometry. No SolidCraft runtime or generated STEP dependency.
- Use OOBB primitives for hardware and always pass `overhang=True`.
- Default to two opposed wave banks and two independent sets of 7 mm OD nylon spacers; lengths 6, 12, 15, 18, 20, 25 or 30 mm, default 12 mm.
- Use socket-cap assembly screws with an absolute 35 mm under-head length maximum.
- The 40 mm NEMA 17 is a fit reference; do not imply the motor bracket/coupling exists until it is designed and checked.
- Regenerate with `python working.py`; verify with `python -m pytest -q` and `python tools/validate_meshes.py` after rendering.

