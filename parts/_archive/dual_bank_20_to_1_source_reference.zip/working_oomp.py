"""Load populated recipes into the standard parts catalogue, without AI tooling."""
import copy
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent


def create_generic(**kwargs):
    kwargs = copy.deepcopy(kwargs)
    kwargs.setdefault("part_filter", "")
    parts = []
    for source in sorted((ROOT / "parts_source").glob("*/working.yaml")):
        if kwargs["part_filter"] not in source.parent.name:
            continue
        part = yaml.safe_load(source.read_text(encoding="utf-8"))
        part["name"] = source.parent.name
        part["name_proper"] = part["name"].replace("_", " ").title()
        part["directory"] = f"parts/{part['name']}"
        folder = ROOT / part["directory"]
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "working.yaml").write_text(
            yaml.safe_dump(part, sort_keys=False), encoding="utf-8"
        )
        parts.append(part)
    return parts


def main(**kwargs):
    return create_generic(**kwargs)


if __name__ == "__main__":
    main()

