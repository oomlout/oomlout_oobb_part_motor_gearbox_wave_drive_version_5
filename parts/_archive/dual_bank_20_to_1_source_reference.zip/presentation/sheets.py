"""Cream technical sheets using the cycloidal presentation's palette and type."""
import copy
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def font(size, bold=False):
    return ImageFont.truetype(str(Path("C:/Windows/Fonts")/("segoeuib.ttf" if bold else "segoeui.ttf")), size)


def publish(**kwargs):
    kwargs = copy.deepcopy(kwargs)
    kwargs.setdefault("folder", Path(__file__).resolve().parent)
    folder = Path(kwargs["folder"])
    style = json.loads((folder/"style.json").read_text())
    (folder/"images").mkdir(exist_ok=True)
    definitions = [
        {
            "key": "assembly",
            "title": "20:1 opposed roller wave gearbox",
            "subtitle": "Fix the turquoise housing. Drive the yellow input. Take the reduced-speed output from the black cage.",
            "footer": "6810 output bearings · 6704 input and wave bearings · OOBB mounting grid",
        },
        {
            "key": "open_mechanism",
            "title": "Inside the roller wave drive",
            "subtitle": "Lower bank exposed: 20 nylon spacers follow its wave wheel. The second bank is opposed by 180 degrees.",
            "footer": "Upper bank and central joints hidden for inspection. Rollers: nylon, 7 mm OD x 12 mm long.",
        },
        {
            "key": "exploded",
            "title": "The complete gearbox stack",
            "subtitle": "26 printed pieces, 40 nylon rollers, 6 bearings, 1 shaft and 136 fasteners. Axial separation is illustrative.",
            "footer": "Two opposed wave wheels · one common output cage · socket cap screws, all at most 35 mm long",
        },
        {
            "key": "motor_fit",
            "title": "40 mm NEMA 17 · motor fit study",
            "subtitle": "Full motor envelope aligned with the gearbox input. The two shafts remain separate.",
            "footer": "42.3 mm body width · 24 mm motor shaft · 31 mm mounting pitch · coupling and bracket still required",
        },
        {
            "key": "motor_side",
            "title": "Motor and input · side elevation",
            "subtitle": "37 mm from motor face to gearbox mounting face; 1 mm clearance between the shaft ends.",
            "footer": "Only 2 mm of gearbox shaft projects below the yellow collar: revise the connection before building a motor mount.",
        },
        {
            "key": "exploded_motor",
            "title": "Opposed wave drive · exploded with motor",
            "subtitle": "Two banks of 7 x 12 mm nylon spacers and a full 40 mm NEMA 17 reference. Axial separation is illustrative.",
            "footer": "Motor shown for fit planning. A mounting bracket and coupling/revised input connection are still required.",
        },
        {
            "key": "parts",
            "title": "Every printed piece",
            "subtitle": "19 designs · 26 printed instances · the 40 nylon spacer rollers are purchased separately.",
            "footer": "All geometry comes from the production OpenSCAD exports. This view is an inventory layout.",
        },
    ]
    for item in definitions:
        raw = Image.open(folder/"raw"/(item["key"]+".png")).convert("RGBA")
        size = (1600, 2080) if item["key"] == "exploded_motor" else (1600, 1790) if item["key"] in ["exploded", "motor_side"] else (1600, 1540) if item["key"] == "motor_fit" else (1600, 1360)
        page = Image.new("RGB", size, "white")
        draw = ImageDraw.Draw(page)
        draw.text((48, 26), item["title"], font=font(46, True), fill="#222625")
        draw.text((50, 99), item["subtitle"], font=font(25), fill="#59615F")
        box = (45, 160, 1510, size[1]-280)
        x, y, width, height = box
        scale = min(width/raw.width, height/raw.height)
        raw = raw.resize((round(raw.width*scale), round(raw.height*scale)), Image.Resampling.LANCZOS)
        page.paste(Image.new("RGB", (width, height), style["background"]), (x, y))
        page.paste(raw, (x+(width-raw.width)//2, y+(height-raw.height)//2), raw)
        draw.text((50, size[1]-112), item["footer"], font=font(23), fill="#59615F")
        draw.text((48, size[1]-47), "OpenSCAD geometry · Blender Cycles studio · Prototype: physical fit and load testing pending.", font=font(22), fill="#59615F")
        page.save(folder/"images"/(item["key"]+".png"))


if __name__ == "__main__":
    publish()
