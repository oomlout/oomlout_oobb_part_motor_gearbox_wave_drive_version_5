"""Editable purchased-motor reference and honest fit views; no invented adapter."""
import copy
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np
import trimesh

import working_scad


def define(**kwargs):
    kwargs = copy.deepcopy(kwargs)
    kwargs.setdefault("motor_body_depth", 40.0)
    kwargs.setdefault("motor_body_width", 42.3)
    kwargs.setdefault("motor_shaft_length", 24.0)
    kwargs.setdefault("motor_shaft_diameter", 5.0)
    kwargs.setdefault("motor_pilot_diameter", 22.0)
    kwargs.setdefault("motor_pilot_height", 2.0)
    kwargs.setdefault("motor_hole_pitch", 31.0)
    kwargs.setdefault("motor_thread_depth", 6.0)
    kwargs.setdefault("motor_cap_depth", 6.0)
    kwargs.setdefault("motor_corner_chamfer", 3.0)
    kwargs.setdefault("motor_shaft_end_gap", 1.0)
    return kwargs


def stage(**kwargs):
    root = Path(kwargs["root"])
    parts = Path(kwargs["part_folder"])
    presentation = Path(kwargs["presentation_folder"])
    c = kwargs["configuration"]
    settings = define(**kwargs.get("motor", {}))
    # Keep the two real shafts separate: motor is an aligned fit reference.
    gearbox_shaft_bottom = -12.0
    face_z = gearbox_shaft_bottom-settings["motor_shaft_end_gap"]-settings["motor_shaft_length"]
    if settings["motor_body_depth"] <= 2*settings["motor_cap_depth"]:
        raise ValueError("Motor body must be longer than both end caps")
    if settings["motor_thread_depth"] > settings["motor_cap_depth"]:
        raise ValueError("Reference thread depth exceeds the front cap")
    hardware = presentation/"hardware"
    hardware.mkdir(exist_ok=True)
    parameter_file = parts/"motor_reference_parameters.scad"
    parameter_file.write_text("// Visual reference only. Edit presentation/motor_reference.py define().\n"+"\n".join(f"{key} = {json.dumps(value)};" for key,value in settings.items())+f"\nmotor_face_z = {face_z};\n",encoding="utf-8")
    shutil.copyfile(root/"wave_components/nema17_reference.scad", parts/"nema17_reference.scad")
    definitions = [
        {
            "part": "nema17_front",
            "material": "steel",
        },
        {
            "part": "nema17_stator",
            "material": "black",
        },
        {
            "part": "nema17_rear",
            "material": "steel",
        },
        {
            "part": "nema17_pilot",
            "material": "steel",
        },
        {
            "part": "nema17_shaft",
            "material": "steel",
        },
        {
            "part": "nema17_connector",
            "material": "black",
        },
    ]
    records, arrays, hashes = [], {}, {}
    mesh_prefix = f'include <{parameter_file.as_posix()}>\ninclude <{(parts/"nema17_reference.scad").as_posix()}>\n$fn=120;\n'
    for item in definitions:
        name = item["part"]
        scad = hardware/(name+".scad")
        scad.write_text(mesh_prefix+name+"();\n",encoding="utf-8")
        working_scad.render_scad(scad,scad.with_suffix(".stl"))
        mesh = trimesh.load(scad.with_suffix(".stl"),force="mesh")
        assert mesh.is_watertight and mesh.volume > 0, name
        mesh.apply_translation([0,0,face_z])
        arrays[name+"_v"] = np.asarray(mesh.vertices)
        arrays[name+"_f"] = np.asarray(mesh.faces)
        hashes[str(scad.with_suffix(".stl").relative_to(root))] = hashlib.sha256(scad.with_suffix(".stl").read_bytes()).hexdigest()
        record = {
            "name": name,
            "part": name,
            "kind": "motor_reference",
            "group": "motor_reference",
            "material": item["material"],
            "open": False,
            "level": -3,
            "views": ["motor_fit", "motor_side", "exploded_motor"],
        }
        records.append(record)
    prefix = 'include <parameters.scad>;\nuse <oobb_hardware.scad>;\ninclude <geometry.scad>;\ninclude <motor_reference_parameters.scad>;\ninclude <nema17_reference.scad>;\n'
    (parts/"motor_fit.scad").write_text(prefix+'assembly(0,0);\ntranslate([0,0,motor_face_z]) nema17_reference();\n',encoding="utf-8")
    (root/"working.scad").write_text(f'include <{parts.relative_to(root).as_posix()}/motor_fit.scad>;\n',encoding="utf-8")
    (parts/"exploded_motor.scad").write_text(prefix+'assembly(0,12);\ntranslate([0,0,motor_face_z-105]) nema17_reference();\n',encoding="utf-8")
    # An exact boolean verifies that the reference does not overlap the gearbox.
    witness = parts/"motor_fit_check.scad"
    witness.write_text(prefix+'translate([80,0,0]) cube([1,1,1]);\nintersection() { assembly(0,0); translate([0,0,motor_face_z]) nema17_reference(); }\n',encoding="utf-8")
    working_scad.render_scad(witness,hardware/"motor_fit_check.stl")
    check = trimesh.load(hardware/"motor_fit_check.stl",force="mesh")
    assert np.allclose(check.bounds,[[80,0,0],[81,1,1]],atol=1e-5)
    assert abs(check.volume-1) < 1e-6
    info = {
        "motor": settings,
        "source": "Cycloidal gearbox gearbox_native/nema17_double_bearing.py: previous 40 mm reference motor; external end-cap and connector details are illustrative.",
        "motor_face_z_mm": face_z,
        "motor_rear_z_mm": face_z-settings["motor_body_depth"],
        "gearbox_mounting_face_z_mm": 0,
        "motor_face_to_gearbox_mounting_face_mm": -face_z,
        "motor_shaft_tip_z_mm": face_z+settings["motor_shaft_length"],
        "gearbox_shaft_bottom_z_mm": gearbox_shaft_bottom,
        "shaft_end_gap_mm": settings["motor_shaft_end_gap"],
        "gearbox_shaft_projection_beyond_collar_mm": c["bearing_z"]-13-gearbox_shaft_bottom,
        "motor_mount_holes_xy_mm": [[x,y] for x in [-15.5,15.5] for y in [-15.5,15.5]],
        "motor_to_gearbox_interference_mm3": 0,
        "fit_status": "Aligned envelope study, not a connected motor conversion. Mounting bracket and shaft coupling/revised input connection are required; current input shaft only projects 2 mm below the collar.",
    }
    (presentation/"motor_fit.json").write_text(json.dumps(info,indent=2),encoding="utf-8")
    return records, arrays, hashes
