"""Editable recipe: populate -> working_oomp -> working_scad. Units are mm."""
import copy
from pathlib import Path

import yaml
from oomp_populate_helper import build_oomp_id

ROOT = Path(__file__).resolve().parent


def define(**kwargs):
    option = {
        "style": "version_5",
        "reduction": 20,
        "bearing_output": "6810",
        "bearing_input": "6704",
        "bearing_wave": "6704",
        "roller_diameter": 7.0,
        "roller_bore_diameter": 3.2,
        "roller_length": 12.0,
        "roller_lengths_available": [6, 12, 15, 18, 20, 25, 30],
        "roller_material": "nylon",
        "central_joint_depth": 6.0,
        "max_screw_length": 35.0,
        "eccentricity": 0.75,
        "wave_radius": 40.0,
        "profile_clearance": 0.15,
        "roller_slot_clearance": 0.30,
        "roller_end_clearance": 0.30,
        "cage_wall": 4.0,
        "cage_plate_depth": 3.0,
        "bearing_seat_clearance": 0.10,
        "journal_clearance": 0.05,
        "bearing_axial_clearance": 0.20,
        "retainer_depth": 4.0,
        "housing_radius": 57.5,
        "housing_flange_width": 119.0,
        "housing_flange_depth": 3.0,
        "housing_flange_corner_radius": 1.5,
        "housing_screw_pitch_radius": 53.0,
        "housing_screw_count": 8,
        "input_shaft_diameter": 5.0,
        "input_shaft_flat_depth": 0.5,
        "shaft_fit_clearance": 0.10,
        "cage_screw_count": 5,
        "cage_screw_pilot_diameter": 1.6,
        "profile_samples_per_cavity": 100,
        "circle_fragments": 120,
        "overhang": True,
        "run_scad": True,
        "run_solidcraft": False,
    }
    option.update(copy.deepcopy(kwargs))
    return option


def get_options(**kwargs):
    option = define(**kwargs)
    option["taxonomy_1"] = "oobb"
    option["taxonomy_2"] = "part"
    option["taxonomy_3"] = "motor_gearbox"
    option["taxonomy_4"] = "wave_drive"
    option["taxonomy_5"] = option["style"]
    option["taxonomy_6"] = f"{option['reduction']}_to_1_reduction"
    details = copy.deepcopy(option)
    details["oobb_name"] = option["style"]
    details["oobb_type"] = "wave_drive"
    option["oobb_details"] = details
    option["id"] = build_oomp_id(option)
    return [option]


def main(**kwargs):
    for option in get_options(**kwargs):
        folder = ROOT / "parts_source" / option["id"]
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "working.yaml").write_text(
            yaml.safe_dump(option, sort_keys=False), encoding="utf-8"
        )


if __name__ == "__main__":
    main()

