include <parameters.scad>;
use <oobb_hardware.scad>;
include <geometry.scad>;
wave_cap();
